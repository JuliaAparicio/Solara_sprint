import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { ThemeContext } from '../context/ThemeContext';

const faqData = [
  {
    id: '1',
    question: 'Como conectar minha conta à Alexa?',
    answer:
      'Acesse a tela de Dispositivos e toque em "Conectar com Alexa". Siga as instruções para vincular sua conta.',
  },
  {
    id: '2',
    question: 'Como visualizar meu histórico de consumo?',
    answer:
      'Na tela Home, você verá o gráfico semanal. Em breve, teremos uma tela dedicada ao histórico completo!',
  },
  {
    id: '3',
    question: 'Posso alterar minha cidade para o clima?',
    answer:
      'Sim! Em breve você poderá editar sua cidade nas configurações do perfil.',
  },
  {
    id: '4',
    question: 'O que significa o saldo de energia?',
    answer:
      'É a diferença entre o que você produziu e consumiu. Se for positivo, você está gerando mais do que consome!',
  },
];

export default function FAQScreen() {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const { darkMode } = useContext(ThemeContext);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const titleColor = darkMode ? '#FFCDD2' : '#C62828';
  const boxColor = darkMode ? '#263238' : '#FBE9E7';
  const questionColor = darkMode ? '#FFFFFF' : '#424242';
  const answerColor = darkMode ? '#B0BEC5' : '#757575';
  const messageColor = darkMode ? '#A5D6A7' : '#2E7D32';

  const renderItem = ({ item }: { item: typeof faqData[0] }) => (
    <View style={[styles.faqBox, { backgroundColor: boxColor }]}>
      <TouchableOpacity onPress={() => toggleExpand(item.id)} style={styles.questionRow}>
        <FontAwesome name="question-circle" size={25} color={titleColor} style={{ marginRight: 10 }} />
        <Text style={[styles.question, { color: questionColor }]}>{item.question}</Text>
      </TouchableOpacity>
      {expandedId === item.id && (
        <Text style={[styles.answer, { color: answerColor }]}>{item.answer}</Text>
      )}
    </View>
  );

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <View style={styles.container}>
        <Text style={[styles.title, { color: titleColor }]}>Perguntas Frequentes</Text>

        <FlatList
          data={faqData}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          style={{ width: '100%' }}
        />

        <Text style={[styles.solaraMessage, { color: messageColor }]}>
          Se ainda tiver dúvidas, estou por aqui!
        </Text>

        <TouchableOpacity
          style={styles.telegramButton}
          onPress={() => Linking.openURL('https://t.me/Solara_Bot_GoodWe')}
        >
          <FontAwesome name="telegram" size={20} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.telegramText}>Falar com o bot no Telegram</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  faqBox: {
    padding: 15,
    borderRadius: 10,
    marginBottom: 12,
    width: '100%',
  },
  questionRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  question: {
    fontSize: 16,
    fontWeight: 'bold',
    flexShrink: 1,
  },
  answer: {
    fontSize: 14,
    marginTop: 10,
  },
  solaraMessage: {
    fontSize: 15,
    textAlign: 'center',
    marginTop: 30,
  },
  telegramButton: {
    flexDirection: 'row',
    backgroundColor: '#0088cc',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  telegramText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
});