import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { FontAwesome } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { ThemeContext } from '../context/ThemeContext';

const screenWidth = Dimensions.get('window').width;

export default function HomeScreen() {
  const { darkMode } = useContext(ThemeContext);

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textPrimary = darkMode ? '#FFCDD2' : '#C62828';
  const textSecondary = darkMode ? '#E0E0E0' : '#424242';
  const boxBackground = darkMode ? '#2C2C2C' : '#FBE9E7';
  const chartBackground = darkMode ? '#1E1E1E' : '#FFFFFF';
  const chartLabelColor = darkMode ? () => '#E0E0E0' : () => '#424242';

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <ScrollView contentContainerStyle={[styles.container, { backgroundColor }]}>
        <Text style={[styles.title, { color: textPrimary }]}>Dashboard Energético</Text>

        <View style={styles.metricsContainer}>
          <View style={[styles.metricBox, { backgroundColor: boxBackground }]}>
            <Text style={[styles.metricLabel, { color: textSecondary }]}>Produção</Text>
            <Text style={[styles.metricValue, { color: textPrimary }]}>14.2 kWh</Text>
          </View>
          <View style={[styles.metricBox, { backgroundColor: boxBackground }]}>
            <Text style={[styles.metricLabel, { color: textSecondary }]}>Consumo</Text>
            <Text style={[styles.metricValue, { color: textPrimary }]}>11.8 kWh</Text>
          </View>
          <View style={[styles.metricBox, { backgroundColor: boxBackground }]}>
            <Text style={[styles.metricLabel, { color: textSecondary }]}>Saldo</Text>
            <Text style={[styles.metricValue, { color: textPrimary }]}>2.4 kWh</Text>
          </View>
        </View>

        <Text style={[styles.graphTitle, { color: textSecondary }]}>Consumo semanal</Text>
        <LineChart
          data={{
            labels: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'],
            datasets: [
              {
                data: [10.5, 9.5, 13.6, 15.0, 11.0, 10.0, 11.5],
                color: () => textPrimary,
                strokeWidth: 2,
              },
            ],
          }}
          width={screenWidth - 40}
          height={280}
          yAxisSuffix="kWh"
          bezier
          chartConfig={{
            backgroundGradientFrom: chartBackground,
            backgroundGradientTo: chartBackground,
            decimalPlaces: 1,
            color: (opacity = 1) => `rgba(198, 40, 40, ${opacity})`,
            labelColor: chartLabelColor,
            propsForDots: {
              r: '6',
              strokeWidth: '2',
              stroke: textPrimary,
            },
            style: {
              borderRadius: 16,
            },
          }}
          style={{
            marginVertical: 20,
            borderRadius: 16,
          }}
        />

        <TouchableOpacity
          style={styles.telegramButton}
          onPress={() => Linking.openURL('https://t.me/Solara_Bot_GoodWe')}
        >
          <FontAwesome name="telegram" size={20} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.telegramText}>Falar com o bot no Telegram</Text>
        </TouchableOpacity>

        <View style={{ height: 60 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 20,
  },
  metricBox: {
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 5,
  },
  metricLabel: {
    fontSize: 15,
  },
  metricValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  graphTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    alignSelf: 'flex-start',
  },
  telegramButton: {
    flexDirection: 'row',
    backgroundColor: '#0088cc',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 20,
  },
  telegramText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
});