import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { ref, get } from 'firebase/database';
import { auth, db } from '../config/firebaseConfig';

export default function LoginScreen({ navigation }: { navigation: any }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const { darkMode } = useContext(ThemeContext);

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textColor = darkMode ? '#FFFFFF' : '#424242';
  const inputBackground = darkMode ? '#1E1E1E' : '#FFFFFF';
  const inputTextColor = darkMode ? '#FFFFFF' : '#000000';
  const inputBorderColor = darkMode ? '#555555' : '#CCCCCC';
  const placeholderColor = darkMode ? '#AAAAAA' : '#888888';
  const buttonColor = '#C62828';
  const buttonTextColor = '#FFFFFF';
  const titleColor = '#C62828';
  const linkColor = '#C62828';
  const noteColor = darkMode ? '#AAAAAA' : '#888888';

  const handleLogin = async () => {
    if (!email && !senha) {
      Alert.alert('Campos obrigatórios', 'Adicione seus dados para entrar.');
      return;
    }

    if (email && !senha) {
      Alert.alert('Campo obrigatório', 'Coloque a senha para entrar.');
      return;
    }

    if (senha.length < 6) {
      Alert.alert('Senha inválida', 'A senha precisa ter pelo menos 6 caracteres.');
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, senha);
      const uid = userCredential.user.uid;

      const snapshot = await get(ref(db, `users/${uid}`));
      const dadosCliente = snapshot.val();

      console.log('Dados do cliente:', dadosCliente);

      Alert.alert('Login realizado', `Bem-vindo, ${dadosCliente?.nome || 'usuário'}!`);
      setEmail('');
      setSenha('');
      navigation.navigate('MainTabs');
    } catch (error: any) {
      Alert.alert('Erro ao entrar', error.message);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Text style={[styles.title, { color: titleColor }]}>Bem-vindo à Solara</Text>
      <Text style={[styles.subtitle, { color: textColor }]}>
        Aplicativo inteligente desenvolvido para a GoodWe
      </Text>

      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="E-mail"
        placeholderTextColor={placeholderColor}
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="Senha"
        placeholderTextColor={placeholderColor}
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />
      <Text style={{ fontSize: 12, color: noteColor, marginBottom: 8 }}>
        A senha deve ter no mínimo 6 caracteres.
      </Text>

      <TouchableOpacity style={[styles.button, { backgroundColor: buttonColor }]} onPress={handleLogin}>
        <Text style={[styles.buttonText, { color: buttonTextColor }]}>Entrar</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={[styles.link, { color: linkColor }]}>Não tem conta? Cadastre-se</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 12,
    marginBottom: 12,
    borderRadius: 8,
    borderWidth: 1,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
    marginTop: 10,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  link: {
    marginTop: 20,
    fontSize: 15,
    textDecorationLine: 'underline',
  },
});