import React, { useState, useContext, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';
import { auth, db } from '../config/firebaseConfig';
import { ref, onValue, set } from 'firebase/database';

export default function EditProfileScreen({ navigation }: { navigation: any }) {
  const { darkMode } = useContext(ThemeContext);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [phone, setPhone] = useState('');

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
const textColor = darkMode ? '#FFFFFF' : '#424242';
const inputBackground = darkMode ? '#1E1E1E' : '#FFFFFF';
const inputBorder = darkMode ? '#555555' : '#CCCCCC';
const placeholderColor = darkMode ? '#AAAAAA' : '#888888';
const buttonColor = '#C62828';
const buttonTextColor = '#FFFFFF';

  useEffect(() => {
    const uid = auth.currentUser?.uid;
    if (!uid) return;

    const userRef = ref(db, `users/${uid}`);
    onValue(userRef, (snapshot) => {
      const dados = snapshot.val();
      if (dados) {
        setName(dados.nome || '');
        setEmail(dados.email || auth.currentUser?.email || '');
        setCity(dados.cidade || '');
        setPhone(dados.telefone || '');
      }
    });
  }, []);

  const handleSave = () => {
    const uid = auth.currentUser?.uid;
    if (!uid) return;

    const userRef = ref(db, `users/${uid}`);
    set(userRef, {
      nome: name,
      email: email,
      cidade: city,
      telefone: phone,
      criadoEm: new Date().toISOString(),
    })
      .then(() => {
        Alert.alert('Sucesso', 'Perfil atualizado com sucesso!');
        navigation.goBack();
      })
      .catch((error) => {
        Alert.alert('Erro', 'Não foi possível salvar os dados.');
        console.error(error);
      });
  };

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Text style={[styles.title, { color: textColor }]}>Editar Perfil</Text>

      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: textColor, borderColor: inputBorder }]}
        value={name}
        onChangeText={setName}
        placeholder="Nome"
        placeholderTextColor={placeholderColor}
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: textColor, borderColor: inputBorder }]}
        value={email}
        onChangeText={setEmail}
        placeholder="E-mail"
        placeholderTextColor={placeholderColor}
        keyboardType="email-address"
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: textColor, borderColor: inputBorder }]}
        value={city}
        onChangeText={setCity}
        placeholder="Cidade"
        placeholderTextColor={placeholderColor}
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: textColor, borderColor: inputBorder }]}
        value={phone}
        onChangeText={setPhone}
        placeholder="Telefone"
        placeholderTextColor={placeholderColor}
        keyboardType="phone-pad"
      />

      <TouchableOpacity style={[styles.saveButton, { backgroundColor: buttonColor }]} onPress={handleSave}>
        <Text style={[styles.saveText, { color: buttonTextColor }]}>Salvar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 30,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
  },
  saveButton: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});