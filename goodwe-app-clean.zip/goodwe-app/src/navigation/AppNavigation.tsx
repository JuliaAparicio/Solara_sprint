import React, { useContext } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { ThemeContext } from '../context/ThemeContext';

// Telas
import Intro from '../screens/intro';
import Login from '../screens/login';
import Register from '../screens/register';
import MainTabs from '../navigation/maintabs';
import FAQScreen from '../screens/FAQ';
import EditProfileScreen from '../screens/editprofile';

export type RootStackParamList = {
  Intro: undefined;
  Login: undefined;
  Register: undefined;
  MainTabs: undefined;
  FAQ: undefined;
  EditProfile: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

export default function AppNavigation() {
  const { darkMode } = useContext(ThemeContext);

  return (
    <NavigationContainer theme={darkMode ? DarkTheme : DefaultTheme}>
      <Stack.Navigator initialRouteName="Intro" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Intro" component={Intro} />
        <Stack.Screen name="Login" component={Login} />
        <Stack.Screen name="Register" component={Register} />
        <Stack.Screen name="MainTabs" component={MainTabs} />
        <Stack.Screen name="FAQ" component={FAQScreen} />
        <Stack.Screen name="EditProfile" component={EditProfileScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}