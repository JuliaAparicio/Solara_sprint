import React, { useContext } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';

const screenWidth = Dimensions.get('window').width;

export default function IntroScreen({ navigation }: { navigation: any }) {
  const { darkMode } = useContext(ThemeContext);

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: darkMode ? '#121212' : '#FFFFFF' },
      ]}
    >
      <Image
        source={require('../assets/Solara2.png')}
        style={styles.image}
        resizeMode="contain"
      />
      <Text
        style={[
          styles.greeting,
          { color: darkMode ? '#FFCDD2' : '#C62828' },
        ]}
      >
        Olá!
      </Text>
      <Text
        style={[
          styles.description,
          { color: darkMode ? '#E0E0E0' : '#424242' },
        ]}
      >
        Estou aqui para te ajudar a gerenciar seu uso de energia.
      </Text>
      <TouchableOpacity
        style={[
          styles.button,
          { backgroundColor: darkMode ? '#FFCDD2' : '#C62828' },
        ]}
        onPress={() => navigation.navigate('Login')}
      >
        <Text
          style={[
            styles.buttonText,
            { color: darkMode ? '#000000' : '#FFFFFF' },
          ]}
        >
          Vamos começar
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  image: {
    width: screenWidth * 0.8, // 80% da largura da tela
    height: screenWidth * 0.8,
    marginBottom: 20,
  },
  greeting: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  description: {
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 30,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
});
