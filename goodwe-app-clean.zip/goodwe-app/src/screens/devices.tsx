import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import { FontAwesome5 } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { ThemeContext } from '../context/ThemeContext';

const devices = [
  { id: '1', name: 'Painel Solar', type: 'solar', status: 'Ativo' },
  { id: '2', name: 'Bateria Inteligente', type: 'battery', status: 'Ativo' },
  { id: '3', name: 'Inversor GoodWe', type: 'inverter', status: 'Offline' },
];

export default function DevicesScreen() {
  const { darkMode } = useContext(ThemeContext);

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textColor = darkMode ? '#FFFFFF' : '#424242';
  const boxColor = darkMode ? '#263238' : '#FBE9E7';
  const statusColor = darkMode ? '#B0BEC5' : '#757575';
  const messageColor = darkMode ? '#A5D6A7' : '#2E7D32';

  const renderItem = ({ item }: { item: typeof devices[0] }) => (
    <View style={[styles.deviceBox, { backgroundColor: boxColor }]}>
      <FontAwesome5
        name={
          item.type === 'solar'
            ? 'sun'
            : item.type === 'battery'
            ? 'battery-full'
            : 'bolt'
        }
        size={30}
        color="#C62828"
        style={{ marginRight: 12 }}
      />
      <View>
        <Text style={[styles.deviceName, { color: textColor }]}>{item.name}</Text>
        <Text style={[styles.deviceStatus, { color: statusColor }]}>
          Status: {item.status}
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <View style={styles.container}>
        <Text style={[styles.title, { color: textColor }]}>Dispositivos Conectados</Text>

        <FlatList
          data={devices}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          style={{ width: '100%', marginBottom: 30 }}
        />

        <Text style={[styles.solaraMessage, { color: messageColor }]}>
          Alexa está pronta para te ajudar com sua energia!
        </Text>

        <TouchableOpacity
          style={styles.alexaButton}
          onPress={() =>
            Linking.openURL('https://apps.apple.com/br/app/amazon-alexa/id944011620')
          }
        >
          <FontAwesome5 name="amazon" size={30} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.alexaText}>Conectar com Alexa</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  deviceBox: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
    width: '100%',
  },
  deviceName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  deviceStatus: {
    fontSize: 16,
  },
  solaraMessage: {
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 20,
  },
  alexaButton: {
    flexDirection: 'row',
    backgroundColor: '#232F3E',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  alexaText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
});