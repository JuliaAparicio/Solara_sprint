import React, { useContext } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { FontAwesome5 } from '@expo/vector-icons';
import { ThemeContext } from '../context/ThemeContext';

import HomeScreen from '../screens/home';
import WeatherScreen from '../screens/weather';
import DevicesScreen from '../screens/devices';
import ProfileScreen from '../screens/profile';

export type MainTabsParamList = {
  Home: undefined;
  Clima: undefined;
  Dispositivos: undefined;
  Perfil: undefined;
};

const Tab = createBottomTabNavigator<MainTabsParamList>();

export default function MainTabs() {
  const { darkMode } = useContext(ThemeContext);

  return (
    <Tab.Navigator
      initialRouteName="Home"
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: darkMode ? '#FFCDD2' : '#C62828',
        tabBarInactiveTintColor: darkMode ? '#B0BEC5' : '#757575',
        tabBarStyle: {
          backgroundColor: darkMode ? '#263238' : '#FFFFFF',
          borderTopColor: darkMode ? '#37474F' : '#EEEEEE',
        },
        tabBarIcon: ({ color, size }) => {
          let iconName: string;

          switch (route.name) {
            case 'Home':
              iconName = 'home';
              break;
            case 'Clima':
              iconName = 'cloud-sun';
              break;
            case 'Dispositivos':
              iconName = 'plug';
              break;
            case 'Perfil':
              iconName = 'user';
              break;
            default:
              iconName = 'circle';
          }

          return <FontAwesome5 name={iconName} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} options={{ tabBarLabel: 'Início' }} />
      <Tab.Screen name="Clima" component={WeatherScreen} options={{ tabBarLabel: 'Clima' }} />
      <Tab.Screen name="Dispositivos" component={DevicesScreen} options={{ tabBarLabel: 'Dispositivos' }} />
      <Tab.Screen name="Perfil" component={ProfileScreen} options={{ tabBarLabel: 'Perfil' }} />
    </Tab.Navigator>
  );
}