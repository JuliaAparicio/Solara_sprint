import React, { useEffect, useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import axios from 'axios';
import { ThemeContext } from '../context/ThemeContext';

const API_KEY = '806a2f2b548d64d80d55406bc0b1de78';
const CITY = 'Santo André';

export default function WeatherScreen() {
  const [weather, setWeather] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const { darkMode } = useContext(ThemeContext);

  const fetchWeather = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${CITY}&units=metric&lang=pt_br&appid=${API_KEY}`
      );
      setWeather(response.data);
    } catch (error) {
      console.error('Erro ao buscar clima:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWeather();
  }, []);

  const getAdvice = () => {
    if (!weather) return '';
    const condition = weather.weather[0].main.toLowerCase();
    const temp = weather.main.temp;

    if (condition.includes('rain')) return 'Está chovendo! Proteja seus equipamentos e feche as janelas.';
    if (condition.includes('cloud')) return 'Dia nublado: aproveite para economizar energia.';
    if (condition.includes('clear') && temp > 25) return 'Dia ensolarado! Ótimo para carregar seus dispositivos com energia solar.';
    if (temp < 15) return 'Está frio! Feche bem as janelas para manter o ambiente aquecido.';
    return 'Clima estável: mantenha seus hábitos sustentáveis!';
  };

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textPrimary = darkMode ? '#FFCDD2' : '#C62828';
  const textSecondary = darkMode ? '#E0E0E0' : '#424242';
  const textTertiary = darkMode ? '#BDBDBD' : '#757575';
  const adviceColor = darkMode ? '#81C784' : '#2E7D32';
  const buttonColor = darkMode ? '#FFCDD2' : '#C62828';
  const buttonTextColor = darkMode ? '#000' : '#fff';

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <View style={styles.container}>
        <Text style={[styles.title, { color: textPrimary }]}>Clima e Conselhos Inteligentes</Text>

        {loading ? (
          <ActivityIndicator size="large" color={textPrimary} />
        ) : (
          <>
            <Text style={[styles.city, { color: textSecondary }]}>{weather.name}</Text>
            <Text style={[styles.temp, { color: textPrimary }]}>{Math.round(weather.main.temp)}°C</Text>
            <Text style={[styles.condition, { color: textTertiary }]}>{weather.weather[0].description}</Text>
            <Text style={[styles.advice, { color: adviceColor }]}>{getAdvice()}</Text>

            <TouchableOpacity
              style={[styles.button, { backgroundColor: buttonColor }]}
              onPress={fetchWeather}
            >
              <Text style={[styles.buttonText, { color: buttonTextColor }]}>Atualizar clima</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  city: {
    fontSize: 20,
    marginBottom: 10,
  },
  temp: {
    fontSize: 50,
    fontWeight: 'bold',
  },
  condition: {
    fontSize: 18,
    marginBottom: 20,
    textTransform: 'capitalize',
  },
  advice: {
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 30,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
});