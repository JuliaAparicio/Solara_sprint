import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { ref, set } from 'firebase/database';
import { auth, db } from '../config/firebaseConfig';

export default function RegisterScreen({ navigation }: { navigation: any }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const { darkMode } = useContext(ThemeContext);

  const handleRegister = async () => {
    if (senha !== confirmarSenha) {
      Alert.alert('Erro', 'As senhas não coincidem');
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, senha);
      const uid = userCredential.user.uid;

      // Salva os dados do cliente no banco
      await set(ref(db, `users/${uid}`), {
        email,
        nome: 'Cliente', // você pode adicionar campo de nome depois
        cidade: 'Indefinida', // ou pedir cidade no cadastro
        criadoEm: new Date().toISOString(),
      });

      Alert.alert('Sucesso', 'Conta criada com sucesso!');
      setEmail('');
      setSenha('');
      setConfirmarSenha('');
      navigation.navigate('Login');
    } catch (error: any) {
      Alert.alert('Erro ao cadastrar', error.message);
    }
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: darkMode ? '#121212' : '#FFFFFF' },
      ]}
    >
      <Text
        style={[
          styles.title,
          { color: darkMode ? '#FFCDD2' : '#C62828' },
        ]}
      >
        Crie sua conta
      </Text>

      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: darkMode ? '#1E1E1E' : '#fff',
            color: darkMode ? '#fff' : '#000',
            borderColor: darkMode ? '#555' : '#ccc',
          },
        ]}
        placeholder="E-mail"
        placeholderTextColor={darkMode ? '#aaa' : '#888'}
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: darkMode ? '#1E1E1E' : '#fff',
            color: darkMode ? '#fff' : '#000',
            borderColor: darkMode ? '#555' : '#ccc',
          },
        ]}
        placeholder="Senha"
        placeholderTextColor={darkMode ? '#aaa' : '#888'}
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: darkMode ? '#1E1E1E' : '#fff',
            color: darkMode ? '#fff' : '#000',
            borderColor: darkMode ? '#555' : '#ccc',
          },
        ]}
        placeholder="Confirmar senha"
        placeholderTextColor={darkMode ? '#aaa' : '#888'}
        value={confirmarSenha}
        onChangeText={setConfirmarSenha}
        secureTextEntry
      />

      <TouchableOpacity
        style={[
          styles.button,
          { backgroundColor: darkMode ? '#FFCDD2' : '#C62828' },
        ]}
        onPress={handleRegister}
      >
        <Text
          style={[
            styles.buttonText,
            { color: darkMode ? '#000' : '#fff' },
          ]}
        >
          Cadastrar
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text
          style={[
            styles.link,
            { color: darkMode ? '#FFCDD2' : '#C62828' },
          ]}
        >
          Já tem conta? Faça login
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 12,
    marginBottom: 12,
    borderRadius: 8,
    borderWidth: 1,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
    marginTop: 10,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  link: {
    marginTop: 20,
    fontSize: 15,
    textDecorationLine: 'underline',
  },
});