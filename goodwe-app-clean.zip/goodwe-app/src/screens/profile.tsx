import React, { useContext, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Switch,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { ThemeContext } from '../context/ThemeContext';

export default function ProfileScreen() {
  const navigation = useNavigation<any>();
  const { darkMode, toggleDarkMode } = useContext(ThemeContext);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textColor = darkMode ? '#FFFFFF' : '#424242';
  const boxColor = darkMode ? '#263238' : '#FBE9E7';
  const messageColor = darkMode ? '#A5D6A7' : '#2E7D32';

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <View style={styles.container}>
        <Text style={[styles.title, { color: textColor }]}>Perfil e Configurações</Text>

        <View style={[styles.profileBox, { backgroundColor: boxColor }]}>
          <Text style={[styles.label, { color: textColor }]}>Nome:</Text>
          <Text style={[styles.value, { color: textColor }]}>Giovanna</Text>

          <Text style={[styles.label, { color: textColor }]}>E-mail:</Text>
          <Text style={[styles.value, { color: textColor }]}>gi123@email.com</Text>

          <Text style={[styles.label, { color: textColor }]}>Cidade:</Text>
          <Text style={[styles.value, { color: textColor }]}>Santo André - SP</Text>
        </View>

        <TouchableOpacity
          style={styles.editButton}
          onPress={() => navigation.navigate('EditProfile')}
        >
          <FontAwesome name="edit" size={18} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.editText}>Editar Perfil</Text>
        </TouchableOpacity>

        <View style={styles.settingsBox}>
          <View style={styles.settingRow}>
            <Text style={[styles.settingLabel, { color: textColor }]}>Notificações</Text>
            <Switch value={notificationsEnabled} onValueChange={setNotificationsEnabled} />
          </View>
          <View style={styles.settingRow}>
            <Text style={[styles.settingLabel, { color: textColor }]}>Modo Escuro</Text>
            <Switch value={darkMode} onValueChange={toggleDarkMode} />
          </View>
        </View>

        <Text style={[styles.solaraMessage, { color: messageColor }]}>
          Qualquer dúvida, estou aqui pra te ajudar!
        </Text>

        <TouchableOpacity
          style={styles.faqButton}
          onPress={() => navigation.navigate('FAQ')}
        >
          <FontAwesome name="question-circle" size={20} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.faqText}>Acessar FAQ</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  container: {
    flex: 1,
    padding: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  profileBox: {
    padding: 20,
    borderRadius: 10,
    width: '100%',
    marginBottom: 20,
  },
  label: {
    fontSize: 14,
  },
  value: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  editButton: {
    flexDirection: 'row',
    backgroundColor: '#C62828',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 30,
  },
  editText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  settingsBox: {
    width: '100%',
    marginBottom: 30,
  },
  settingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  settingLabel: {
    fontSize: 16,
  },
  solaraMessage: {
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 20,
  },
  faqButton: {
    flexDirection: 'row',
    backgroundColor: '#0088cc',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  faqText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});