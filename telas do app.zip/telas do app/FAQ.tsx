import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  FlatList,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import { ThemeContext } from '../context/ThemeContext';

const faqData = [
  {
    id: '1',
    question: 'Como conectar minha conta à Alexa?',
    answer:
      'Vá até a tela de Dispositivos e toque em "Conectar com Alexa". Isso abrirá o app da Alexa, onde você poderá vincular sua conta e ativar a Skill necessária. Após isso, seus dispositivos estarão prontos para comandos de voz!',
  },
  {
    id: '2',
    question: 'Como visualizar meu histórico de consumo?',
    answer:
      'Na tela inicial, você já encontra um gráfico com o resumo semanal. Em breve, lançaremos uma área dedicada ao histórico completo, com filtros por dia, mês e tipo de consumo.',
  },
  {
    id: '3',
    question: 'Posso alterar minha cidade para o clima?',
    answer:
      'Sim! Basta acessar a tela de Perfil, tocar em "Editar Perfil" e atualizar sua cidade. Isso ajusta os dados climáticos exibidos no app.',
  },
  {
    id: '4',
    question: 'O que significa o saldo de energia?',
    answer:
      'É a diferença entre o que você gerou e o que consumiu. Se o saldo for positivo, você está produzindo mais energia do que usa — ótimo sinal de eficiência!',
  },
  {
    id: '5',
    question: 'Como configurar minha tomada inteligente?',
    answer:
      'Depois de vincular sua conta à Alexa, vá até a tela de Dispositivos e toque na Tomada Inteligente. Você poderá visualizar o status, consumo e até controlar remotamente.',
  },
  {
    id: '6',
    question: 'O que fazer se minha tomada estiver offline?',
    answer:
      'Verifique se ela está conectada ao Wi-Fi e ligada corretamente. Se o problema persistir, reinicie o dispositivo e confira se a Skill da Alexa está ativa.',
  },
  {
    id: '7',
    question: 'Como alterar meu telefone ou e-mail?',
    answer:
      'Na tela de Perfil, toque em "Editar Perfil" e atualize seus dados. As alterações são salvas automaticamente no Firebase e refletidas em todo o app.',
  },
];

export default function FAQScreen() {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const { darkMode } = useContext(ThemeContext);

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const titleColor = '#C62828';
  const boxColor = darkMode ? '#263238' : '#FBE9E7';
  const questionColor = darkMode ? '#FFFFFF' : '#424242';
  const answerColor = darkMode ? '#B0BEC5' : '#757575';
  const messageColor = darkMode ? '#A5D6A7' : '#2E7D32';

  const renderItem = ({ item }: { item: typeof faqData[0] }) => (
    <View style={[styles.faqBox, { backgroundColor: boxColor }]}>
      <TouchableOpacity onPress={() => toggleExpand(item.id)} style={styles.questionRow}>
        <FontAwesome name="question-circle" size={25} color={titleColor} style={{ marginRight: 10 }} />
        <Text style={[styles.question, { color: questionColor }]}>{item.question}</Text>
      </TouchableOpacity>
      {expandedId === item.id && (
        <Text style={[styles.answer, { color: answerColor }]}>{item.answer}</Text>
      )}
    </View>
  );

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <View style={styles.container}>
        <Text style={[styles.title, { color: titleColor }]}>Perguntas Frequentes</Text>

        <FlatList
          data={faqData}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          style={{ width: '100%' }}
        />

        <Text style={[styles.solaraMessage, { color: messageColor }]}>
          Se ainda tiver dúvidas, estou por aqui!
        </Text>

        <TouchableOpacity
          style={styles.telegramButton}
          onPress={() => Linking.openURL('https://t.me/Solara_Bot_GoodWe')}
        >
          <FontAwesome name="telegram" size={20} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.telegramText}>Falar com o bot no Telegram</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  faqBox: {
    padding: 15,
    borderRadius: 10,
    marginBottom: 12,
    width: '100%',
  },
  questionRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  question: {
    fontSize: 16,
    fontWeight: 'bold',
    flexShrink: 1,
  },
  answer: {
    fontSize: 14,
    marginTop: 10,
  },
  solaraMessage: {
    fontSize: 15,
    textAlign: 'center',
    marginTop: 30,
  },
  telegramButton: {
    flexDirection: 'row',
    backgroundColor: '#0088cc',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  telegramText: {
    color: '#fff',
    fontSize: 20,
    fontWeight: 'bold',
  },
});