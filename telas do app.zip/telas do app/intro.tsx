import React, { useContext } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, Dimensions } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';

const screenWidth = Dimensions.get('window').width;

export default function IntroScreen({ navigation }: { navigation: any }) {
  const { darkMode } = useContext(ThemeContext);

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textColor = darkMode ? '#FFFFFF' : '#424242';
  const buttonColor = '#C62828'; // vermelho fixo
  const buttonTextColor = '#FFFFFF'; // branco fixo
  const titleColor = '#C62828'; // vermelho fixo

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Image
        source={require('../assets/Solara2.png')}
        style={styles.image}
        resizeMode="contain"
      />
      <Text style={[styles.greeting, { color: titleColor }]}>Olá!</Text>
      <Text style={[styles.description, { color: textColor }]}>
        Estou aqui para te ajudar a gerenciar seu uso de energia.
      </Text>
      <TouchableOpacity
        style={[styles.button, { backgroundColor: buttonColor }]}
        onPress={() => navigation.navigate('Login')}
      >
        <Text style={[styles.buttonText, { color: buttonTextColor }]}>Vamos começar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  image: {
    width: screenWidth * 0.8,
    height: screenWidth * 0.8,
    marginBottom: 20,
  },
  greeting: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  description: {
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 30,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
});