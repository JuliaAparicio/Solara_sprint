import { exec } from "child_process";

// Reinicia o servidor e o ngrok automaticamente
function startServer() {
  console.log("🚀 Iniciando servidor local...");
  const server = exec("node server.js");

  server.stdout.on("data", (data) => console.log(data.toString()));
  server.stderr.on("data", (data) => console.error(data.toString()));
}

function startNgrok() {
  console.log("🌐 Iniciando túnel ngrok...");
  const ngrok = exec("ngrok http 4000");

  ngrok.stdout.on("data", (data) => console.log(data.toString()));
  ngrok.stderr.on("data", (data) => console.error(data.toString()));
}

// Se cair o túnel, reinicia automaticamente
startServer();
setTimeout(startNgrok, 2000); // espera o servidor subir