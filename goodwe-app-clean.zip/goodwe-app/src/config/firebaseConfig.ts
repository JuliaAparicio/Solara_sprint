// src/config/firebaseConfig.ts
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getDatabase } from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyC1SlFO01GVZtSDa-XYWiuV0l4cGw9r-T0",
  authDomain: "goodweapp.firebaseapp.com",
  databaseURL: "https://goodweapp-default-rtdb.firebaseio.com",
  projectId: "goodweapp",
  storageBucket: "goodweapp.firebasestorage.app",
  messagingSenderId: "819447280111",
  appId: "1:819447280111:web:40e3077de2532780ee861a"
};

const app = initializeApp(firebaseConfig);

// ✅ Aqui estão os exports que precisam existir
export const auth = getAuth(app);
export const db = getDatabase(app);