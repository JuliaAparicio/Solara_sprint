import axios from "axios";
import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();

const ACCESS_ID = process.env.TUYA_ACCESS_ID;
const ACCESS_SECRET = process.env.TUYA_ACCESS_SECRET;
const DEVICE_ID = process.env.TUYA_DEVICE_ID;
const TUYA_URL = process.env.TUYA_API_URL; // exemplo: https://openapi.tuyaus.com

let TUYA_TOKEN = null;

function tuyaSignV2(path, method = "GET", body = "", accessToken = "") {
  const t = Date.now().toString();
  const bodyHash = crypto.createHash("sha256").update(body).digest("hex");
  const stringToSign = `${method}\n${bodyHash}\n\n${path}`;
  const signStr = ACCESS_ID + accessToken + t + stringToSign;
  const sign = crypto.createHmac("sha256", ACCESS_SECRET)
    .update(signStr, "utf8")
    .digest("hex")
    .toUpperCase();
  return { sign, t };
}

async function getTuyaToken() {
  const path = "/v1.0/token?grant_type=1";
  const { sign, t } = tuyaSignV2(path, "GET");
  const res = await axios.get(`${TUYA_URL}${path}`, {
    headers: { client_id: ACCESS_ID, sign, t, sign_method: "HMAC-SHA256" },
  });
  TUYA_TOKEN = res.data.result.access_token;
  console.log("✅ Token obtido!");
}

async function sendCommand(action) {
  if (!TUYA_TOKEN) await getTuyaToken();

  const path = `/v1.0/devices/${DEVICE_ID}/commands`;
  const body = JSON.stringify({
    commands: [{ code: "switch_1", value: action === "on" }],
  });
  const { sign, t } = tuyaSignV2(path, "POST", body, TUYA_TOKEN);

  try {
    const res = await axios.post(`${TUYA_URL}${path}`, JSON.parse(body), {
      headers: {
        client_id: ACCESS_ID,
        sign,
        t,
        sign_method: "HMAC-SHA256",
        access_token: TUYA_TOKEN,
      },
    });
    console.log("📡 Resposta da Tuya:", res.data);
  } catch (err) {
    console.error("❌ Erro:", err.response?.data || err.message);
  }
}

await sendCommand("on"); // tente ligar
setTimeout(() => sendCommand("off"), 4000); // depois de 4s, desliga