import React, { useEffect, useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  SafeAreaView,
} from 'react-native';
import axios from 'axios';
import * as Location from 'expo-location';
import { ThemeContext } from '../context/ThemeContext';
import { ref, get } from 'firebase/database';
import { auth, db } from '../config/firebaseConfig';

const API_KEY = '25f2085289724b81b2b165029250210'; // sua chave da WeatherAPI

export default function WeatherScreen() {
  const [weather, setWeather] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [cidadeCadastrada, setCidadeCadastrada] = useState<string>(''); // cidade do Firebase
  const { darkMode } = useContext(ThemeContext);

  const buscarCidadeDoCliente = async () => {
    const uid = auth.currentUser?.uid;
    if (!uid) return null;

    try {
      const snapshot = await get(ref(db, `users/${uid}`));
      const dados = snapshot.val();
      return dados?.cidade || null;
    } catch (error) {
      console.error('Erro ao buscar cidade do cliente:', error);
      return null;
    }
  };

  const fetchWeather = async (lat?: number, lon?: number) => {
    try {
      setLoading(true);

      const response = await axios.get('https://api.weatherapi.com/v1/current.json', {
        params: {
          key: API_KEY,
          q: `${lat},${lon}`,
          lang: 'pt',
        },
      });

      const dados = response.data;
      setWeather({
        city: dados.location.name,
        temp: dados.current.temp_c,
        condition: dados.current.condition.text,
        last_updated: dados.current.last_updated,
      });
    } catch (error) {
      console.error('Erro ao buscar clima:', error);
    } finally {
      setLoading(false);
    }
  };

  const carregarLocalizacaoEClima = async () => {
    try {
      const cidadeCliente = await buscarCidadeDoCliente();
      if (cidadeCliente) setCidadeCadastrada(cidadeCliente);

      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Permissão de localização negada');
        await fetchWeather(); // fallback
        return;
      }

      const local = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = local.coords;

      await fetchWeather(latitude, longitude);
    } catch (error) {
      console.error('Erro ao obter localização:', error);
      await fetchWeather(); // fallback
    }
  };

  useEffect(() => {
    carregarLocalizacaoEClima();
  }, []);

  const getAdvice = () => {
    if (!weather) return '';
    const descricao = weather.condition.toLowerCase();
    const temp = weather.temp;

    if (descricao.includes('chuva')) return 'Está chovendo! Proteja seus equipamentos e feche as janelas.';
    if (descricao.includes('nublado')) return 'Dia nublado: aproveite para economizar energia.';
    if (descricao.includes('sol') && temp > 25) return 'Dia ensolarado! Ótimo para carregar seus dispositivos com energia solar.';
    if (temp < 15) return 'Está frio! Feche bem as janelas para manter o ambiente aquecido.';
    return 'Clima estável: mantenha seus hábitos sustentáveis!';
  };

const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
const textPrimary = '#C62828'; // vermelho fixo
const textSecondary = darkMode ? '#FFFFFF' : '#424242'; // textos principais
const textTertiary = darkMode ? '#B0BEC5' : '#757575'; // textos secundários
const adviceColor = darkMode ? '#A5D6A7' : '#2E7D32'; // verde suave no escuro
const buttonColor = '#C62828'; // vermelho fixo
const buttonTextColor = '#FFFFFF'; // branco fixo

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <View style={styles.container}>
        <Text style={[styles.title, { color: textPrimary }]}>Clima e Conselhos Inteligentes</Text>

        {loading ? (
          <ActivityIndicator size="large" color={textPrimary} />
        ) : (
          <>
            <Text style={[styles.city, { color: textSecondary }]}>
              {cidadeCadastrada || weather.city}
            </Text>
            <Text style={[styles.temp, { color: textPrimary }]}>{Math.round(weather.temp)}°C</Text>
            <Text style={[styles.condition, { color: textTertiary }]}>{weather.condition}</Text>
            <Text style={[styles.note, { color: textTertiary }]}>
              Temperatura estimada com base na sua localização
            </Text>
            <Text style={[styles.note, { color: textTertiary }]}>
              Atualizado às {weather.last_updated}
            </Text>
            <Text style={[styles.advice, { color: adviceColor }]}>{getAdvice()}</Text>

            <TouchableOpacity
              style={[styles.button, { backgroundColor: buttonColor }]}
              onPress={carregarLocalizacaoEClima}
            >
              <Text style={[styles.buttonText, { color: buttonTextColor }]}>Atualizar clima</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flex: 1,
    padding: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  city: {
    fontSize: 20,
    marginBottom: 10,
  },
  temp: {
    fontSize: 50,
    fontWeight: 'bold',
  },
  condition: {
    fontSize: 18,
    marginBottom: 10,
    textTransform: 'capitalize',
  },
  note: {
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 5,
  },
  advice: {
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 30,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
});