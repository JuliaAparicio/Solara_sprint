import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { ref, set } from 'firebase/database';
import { auth, db } from '../config/firebaseConfig';

export default function RegisterScreen({ navigation }: { navigation: any }) {
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [cidade, setCidade] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');
  const { darkMode } = useContext(ThemeContext);

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textColor = darkMode ? '#FFFFFF' : '#424242';
  const inputBackground = darkMode ? '#1E1E1E' : '#FFFFFF';
  const inputTextColor = darkMode ? '#FFFFFF' : '#000000';
  const inputBorderColor = darkMode ? '#555555' : '#CCCCCC';
  const placeholderColor = darkMode ? '#AAAAAA' : '#888888';
  const buttonColor = '#C62828';
  const buttonTextColor = '#FFFFFF';
  const titleColor = '#C62828';
  const linkColor = '#C62828';
  const noteColor = darkMode ? '#AAAAAA' : '#888888';

  const handleRegister = async () => {
    if (!email && !senha && !confirmarSenha) {
      Alert.alert('Campos obrigatórios', 'Adicione seus dados para se cadastrar.');
      return;
    }

    if (senha.length < 6) {
      Alert.alert('Senha inválida', 'A senha precisa ter pelo menos 6 caracteres.');
      return;
    }

    if (senha !== confirmarSenha) {
      Alert.alert('Erro', 'As senhas não coincidem.');
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, senha);
      const uid = userCredential.user.uid;

      await set(ref(db, `users/${uid}`), {
        nome,
        telefone,
        cidade,
        email,
        criadoEm: new Date().toISOString(),
      });

      Alert.alert('Sucesso', 'Conta criada com sucesso!');
      setNome('');
      setTelefone('');
      setCidade('');
      setEmail('');
      setSenha('');
      setConfirmarSenha('');
      navigation.navigate('Login');
    } catch (error: any) {
      Alert.alert('Erro ao cadastrar', error.message);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Text style={[styles.title, { color: titleColor }]}>Crie sua conta</Text>

      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="Nome completo"
        placeholderTextColor={placeholderColor}
        value={nome}
        onChangeText={setNome}
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="Telefone"
        placeholderTextColor={placeholderColor}
        value={telefone}
        onChangeText={setTelefone}
        keyboardType="phone-pad"
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="Cidade"
        placeholderTextColor={placeholderColor}
        value={cidade}
        onChangeText={setCidade}
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="E-mail"
        placeholderTextColor={placeholderColor}
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="Senha"
        placeholderTextColor={placeholderColor}
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />
      <Text style={{ fontSize: 12, color: noteColor, marginBottom: 8 }}>
        A senha deve ter no mínimo 6 caracteres.
      </Text>
      <TextInput
        style={[styles.input, { backgroundColor: inputBackground, color: inputTextColor, borderColor: inputBorderColor }]}
        placeholder="Confirmar senha"
        placeholderTextColor={placeholderColor}
        value={confirmarSenha}
        onChangeText={setConfirmarSenha}
        secureTextEntry
      />

      <TouchableOpacity style={[styles.button, { backgroundColor: buttonColor }]} onPress={handleRegister}>
        <Text style={[styles.buttonText, { color: buttonTextColor }]}>Cadastrar</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text style={[styles.link, { color: linkColor }]}>Já tem conta? Faça login</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 12,
    marginBottom: 12,
    borderRadius: 8,
    borderWidth: 1,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
    marginTop: 10,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  link: {
    marginTop: 20,
    fontSize: 15,
    textDecorationLine: 'underline',
  },
});