import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { ref, get } from 'firebase/database';
import { auth, db } from '../config/firebaseConfig'; // ajuste o caminho se necessário

export default function LoginScreen({ navigation }: { navigation: any }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const { darkMode } = useContext(ThemeContext);

  const handleLogin = async () => {
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, senha);
      const uid = userCredential.user.uid;

      // Busca os dados do cliente no banco
      const snapshot = await get(ref(db, `users/${uid}`));
      const dadosCliente = snapshot.val();

      console.log('Dados do cliente:', dadosCliente);

      Alert.alert('Login realizado', `Bem-vindo, ${dadosCliente?.nome || 'usuário'}!`);
      setEmail('');
      setSenha('');
      navigation.navigate('MainTabs');
    } catch (error: any) {
      Alert.alert('Erro ao entrar', error.message);
    }
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: darkMode ? '#121212' : '#FFFFFF' },
      ]}
    >
      <Text
        style={[
          styles.title,
          { color: darkMode ? '#FFCDD2' : '#C62828' },
        ]}
      >
        Bem-vindo à Solara
      </Text>
      <Text
        style={[
          styles.subtitle,
          { color: darkMode ? '#E0E0E0' : '#424242' },
        ]}
      >
        Aplicativo inteligente desenvolvido para a GoodWe
      </Text>

      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: darkMode ? '#1E1E1E' : '#fff',
            color: darkMode ? '#fff' : '#000',
            borderColor: darkMode ? '#555' : '#ccc',
          },
        ]}
        placeholder="E-mail"
        placeholderTextColor={darkMode ? '#aaa' : '#888'}
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: darkMode ? '#1E1E1E' : '#fff',
            color: darkMode ? '#fff' : '#000',
            borderColor: darkMode ? '#555' : '#ccc',
          },
        ]}
        placeholder="Senha"
        placeholderTextColor={darkMode ? '#aaa' : '#888'}
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />

      <TouchableOpacity
        style={[
          styles.button,
          { backgroundColor: darkMode ? '#FFCDD2' : '#C62828' },
        ]}
        onPress={handleLogin}
      >
        <Text
          style={[
            styles.buttonText,
            { color: darkMode ? '#000' : '#fff' },
          ]}
        >
          Entrar
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text
          style={[
            styles.link,
            { color: darkMode ? '#FFCDD2' : '#C62828' },
          ]}
        >
          Não tem conta? Cadastre-se
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    width: '100%',
    padding: 12,
    marginBottom: 12,
    borderRadius: 8,
    borderWidth: 1,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 8,
    marginTop: 10,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  link: {
    marginTop: 20,
    fontSize: 15,
    textDecorationLine: 'underline',
  },
});