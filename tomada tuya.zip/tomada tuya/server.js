import express from "express";
import axios from "axios";
import crypto from "crypto";
import dotenv from "dotenv";
import cors from "cors";
import { initializeApp } from "firebase/app";
import { getDatabase, ref, set, onValue } from "firebase/database";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// ============ FIREBASE ============
const firebaseConfig = {
  databaseURL: process.env.FIREBASE_DATABASE_URL,
};
const firebaseApp = initializeApp(firebaseConfig);
const db = getDatabase(firebaseApp);

// ============ TUYA CONFIG ============
const ACCESS_ID = process.env.TUYA_ACCESS_ID;
const ACCESS_SECRET = process.env.TUYA_ACCESS_SECRET;
const DEVICE_ID = process.env.TUYA_DEVICE_ID;
const TUYA_URL = process.env.TUYA_API_URL;

let TUYA_TOKEN = null;

// ============ GOODWE CONFIG ============
const GOODWE_API_URL = process.env.GOODWE_API_URL;
const GOODWE_TOKEN = process.env.GOODWE_TOKEN;
const GOODWE_PLANT_ID = process.env.GOODWE_PLANT_ID;

// ============ ASSINATURA TUYA ============
function tuyaSignV2(path, method = "GET", body = "", accessToken = "") {
  const t = Date.now().toString();
  const bodyHash = crypto.createHash("sha256").update(body).digest("hex");
  const stringToSign = `${method}\n${bodyHash}\n\n${path}`;
  const signStr = ACCESS_ID + accessToken + t + stringToSign;
  const sign = crypto
    .createHmac("sha256", ACCESS_SECRET)
    .update(signStr, "utf8")
    .digest("hex")
    .toUpperCase();
  return { sign, t };
}

// ============ TOKEN TUYA ============
async function getTuyaToken() {
  try {
    console.log("🔐 Solicitando novo token Tuya...");
    const path = "/v1.0/token?grant_type=1";
    const { sign, t } = tuyaSignV2(path, "GET");

    const response = await axios.get(`${TUYA_URL}${path}`, {
      headers: {
        client_id: ACCESS_ID,
        sign,
        t,
        sign_method: "HMAC-SHA256",
      },
    });

    TUYA_TOKEN = response.data.result?.access_token;
    console.log("✅ Token Tuya obtido com sucesso!");
  } catch (err) {
    console.error("❌ Erro ao obter token Tuya:", err.response?.data || err.message);
  }
}

// ============ STATUS TUYA ============
async function getTuyaDeviceStatus() {
  try {
    if (!TUYA_TOKEN) await getTuyaToken();

    const path = `/v1.0/devices/${DEVICE_ID}/status`;
    const { sign, t } = tuyaSignV2(path, "GET", "", TUYA_TOKEN);

    const response = await axios.get(`${TUYA_URL}${path}`, {
      headers: {
        client_id: ACCESS_ID,
        sign,
        t,
        sign_method: "HMAC-SHA256",
        access_token: TUYA_TOKEN,
      },
    });

    const data = response.data?.result;
    if (!data || !Array.isArray(data)) {
      console.warn("⚠️ Resposta inesperada da Tuya:", response.data);
      return;
    }

    const statusMap = {};
    data.forEach((item) => (statusMap[item.code] = item.value));

    await set(ref(db, "dispositivos/tuya"), {
      online: statusMap.switch_1 || false,
      power: statusMap.cur_power || 0,
      current: statusMap.cur_current || 0,
      voltage: statusMap.cur_voltage || 0,
      updatedAt: new Date().toISOString(),
    });

    console.log("⚡ Status Tuya atualizado no Firebase!");
  } catch (err) {
    if (err.response?.status === 401) {
      console.warn("🔄 Token expirado — renovando...");
      TUYA_TOKEN = null;
      await getTuyaToken();
    } else {
      console.error("❌ Erro ao buscar status Tuya:", err.message);
    }
  }
}

// ============ COMANDOS TUYA ============
function listenFirebaseCommands() {
  const cmdRef = ref(db, "comandos/tuya");
  onValue(cmdRef, async (snapshot) => {
    const command = snapshot.val();
    if (!command) return;

    const action = command.acao;
    console.log(`⚡ Comando Firebase recebido: ${action}`);

    try {
      if (!TUYA_TOKEN) await getTuyaToken();

      const path = `/v1.0/devices/${DEVICE_ID}/commands`;
      const body = JSON.stringify({
        commands: [{ code: "switch_1", value: action === "on" }],
      });
      const { sign, t } = tuyaSignV2(path, "POST", body, TUYA_TOKEN);

      const response = await axios.post(`${TUYA_URL}${path}`, JSON.parse(body), {
        headers: {
          client_id: ACCESS_ID,
          sign,
          t,
          sign_method: "HMAC-SHA256",
          access_token: TUYA_TOKEN,
        },
      });

      if (response.data.success) {
        console.log(`✅ Steck ${action === "on" ? "ligada" : "desligada"} via Firebase!`);
        await set(ref(db, "dispositivos/tuya/online"), action === "on");
      } else {
        console.warn("⚠️ Comando Tuya retornou sem sucesso:", response.data);
      }

      await set(cmdRef, null);
    } catch (err) {
      console.error("❌ Erro no comando Firebase:", err.message);
    }
  });
}

// ============ GOODWE INTEGRAÇÃO ============
async function getGoodweData() {
  try {
    const response = await axios.post(
      GOODWE_API_URL,
      { powerStationId: GOODWE_PLANT_ID },
      { headers: { Token: GOODWE_TOKEN } }
    );

    const plant = response.data?.data;
    if (!plant) throw new Error("Sem dados da GoodWe");

    const info = {
      status: plant.status || "Sem conexão",
      power: plant.power || 0,
      todayEnergy: plant.todayEnergy || 0,
      totalEnergy: plant.totalEnergy || 0,
      temperature: plant.temperature || 0,
      updatedAt: new Date().toISOString(),
    };

    await set(ref(db, "dispositivos/goodwe"), info);
    console.log("☀️ Dados GoodWe atualizados no Firebase!");
  } catch (err) {
    console.error("⚠️ Erro ao buscar dados da GoodWe:", err.message);
  }
}

// ============ ATUALIZAÇÃO AUTOMÁTICA ============
async function autoUpdateAll() {
  await getTuyaDeviceStatus();
  await getGoodweData();
  console.log("📡 Atualização automática concluída:", new Date().toLocaleTimeString());
}

// ============ ENDPOINTS ============
app.get("/api/devices", async (req, res) => {
  res.json({ success: true, message: "Servidor ativo e sincronizado." });
});

// ============ INICIALIZA SERVIDOR ============
app.listen(process.env.PORT || 4000, () => {
  console.log(`✅ Servidor rodando em http://localhost:${process.env.PORT || 4000}`);
  getTuyaToken();
  listenFirebaseCommands();
  autoUpdateAll();
  setInterval(autoUpdateAll, 10000);
});