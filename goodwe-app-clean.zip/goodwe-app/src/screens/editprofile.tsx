import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { ThemeContext } from '../context/ThemeContext';

export default function EditProfileScreen({ navigation }: { navigation: any }) {
  const [name, setName] = useState('Giovanna');
  const [email, setEmail] = useState('gi123@email.com');
  const [city, setCity] = useState('Santo André - SP');
  const { darkMode } = useContext(ThemeContext);

  const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
  const textColor = darkMode ? '#FFFFFF' : '#424242';
  const inputBackground = darkMode ? '#1E1E1E' : '#FFFFFF';
  const inputBorder = darkMode ? '#555' : '#CCC';
  const placeholderColor = darkMode ? '#AAA' : '#888';
  const buttonColor = darkMode ? '#FFCDD2' : '#C62828';
  const buttonTextColor = darkMode ? '#000' : '#FFF';

  return (
    <View style={[styles.container, { backgroundColor }]}>
      <Text style={[styles.title, { color: textColor }]}>Editar Perfil</Text>

      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: inputBackground,
            color: textColor,
            borderColor: inputBorder,
          },
        ]}
        value={name}
        onChangeText={setName}
        placeholder="Nome"
        placeholderTextColor={placeholderColor}
      />
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: inputBackground,
            color: textColor,
            borderColor: inputBorder,
          },
        ]}
        value={email}
        onChangeText={setEmail}
        placeholder="E-mail"
        placeholderTextColor={placeholderColor}
      />
      <TextInput
        style={[
          styles.input,
          {
            backgroundColor: inputBackground,
            color: textColor,
            borderColor: inputBorder,
          },
        ]}
        value={city}
        onChangeText={setCity}
        placeholder="Cidade"
        placeholderTextColor={placeholderColor}
      />

      <TouchableOpacity
        style={[styles.saveButton, { backgroundColor: buttonColor }]}
        onPress={() => navigation.goBack()}
      >
        <Text style={[styles.saveText, { color: buttonTextColor }]}>Salvar</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 30,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
  },
  saveButton: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});