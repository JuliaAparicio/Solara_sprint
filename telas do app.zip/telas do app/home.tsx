import React, { useContext, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  ScrollView,
  SafeAreaView,
} from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { ThemeContext } from '../context/ThemeContext';
import { ref, onValue } from 'firebase/database';
import { auth, db } from '../config/firebaseConfig';

const screenWidth = Dimensions.get('window').width;

export default function HomeScreen() {
  const { darkMode } = useContext(ThemeContext);
  const [consumo, setConsumo] = useState(0);
  const [producao, setProducao] = useState(0);
  const [saldo, setSaldo] = useState(0);
  const [corrente, setCorrente] = useState(0);
  const [tensao, setTensao] = useState(0);
  const [graficoSemanal, setGraficoSemanal] = useState<number[]>([]);
  const [graficoMensal, setGraficoMensal] = useState<number[]>([]);

const backgroundColor = darkMode ? '#121212' : '#FFFFFF';
const textColor = darkMode ? '#FFFFFF' : '#424242'; // textos gerais
const boxBackground = darkMode ? '#263238' : '#FBE9E7'; // fundo das caixas
const textSecondary = darkMode ? '#B0BEC5' : '#757575'; // rótulos
const textPrimary = '#C62828'; // vermelho fixo, independente do tema
const chartBackground = darkMode ? '#121212' : '#FFFFFF';
const chartLabelColor = darkMode ? () => '#B0BEC5' : () => '#757575';
  const calcularProducaoSimulada = () => {
  const hora = new Date().getHours();
  const irradiancia = hora >= 6 && hora <= 18 ? 0.8 : 0.1;
  const potenciaPainel = 4.5; // kW
  return irradiancia * potenciaPainel;
};

useEffect(() => {
    const uid = auth.currentUser?.uid;
    if (!uid) return;

    const tomadaRef = ref(db, `users/${uid}/tomadaInteligente`);
    onValue(tomadaRef, (snapshot) => {
      const dados = snapshot.val();
      const consumoAtual = dados?.potencia ? parseFloat(dados.potencia) : 0.5;
      const correnteAtual = dados?.corrente ? parseFloat(dados.corrente) : 0;
      const tensaoAtual = dados?.tensao ? parseFloat(dados.tensao) : 0;

      const producaoAtual = calcularProducaoSimulada();

      setConsumo(consumoAtual);
      setProducao(producaoAtual);
      setSaldo(producaoAtual - consumoAtual);
      setCorrente(correnteAtual);
      setTensao(tensaoAtual);
    });

    setGraficoSemanal([10.5, 9.5, 13.6, 15.0, 11.0, 10.0, 11.5]);
    setGraficoMensal([
      320, 310, 298, 340, 360, 370, 390, 410, 400, 380, 370, 360,
    ]);
  }, []);

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor }]}>
      <ScrollView contentContainerStyle={[styles.container, { backgroundColor }]}>
        <Text style={[styles.title, { color: textPrimary }]}>Dashboard Energético</Text>

        <View style={styles.metricsContainer}>
          <View style={[styles.metricBox, { backgroundColor: boxBackground }]}>
            <Text style={[styles.metricLabel, { color: textSecondary }]}>Produção</Text>
            <Text style={[styles.metricValue, { color: textPrimary }]}>
              {producao.toFixed(1)} kWh
            </Text>
          </View>
          <View style={[styles.metricBox, { backgroundColor: boxBackground }]}>
            <Text style={[styles.metricLabel, { color: textSecondary }]}>Consumo</Text>
            <Text style={[styles.metricValue, { color: textPrimary }]}>
              {consumo.toFixed(1)} kWh
            </Text>
          </View>
          <View style={[styles.metricBox, { backgroundColor: boxBackground }]}>
            <Text style={[styles.metricLabel, { color: textSecondary }]}>Saldo</Text>
            <Text style={[styles.metricValue, { color: textPrimary }]}>
              {saldo.toFixed(1)} kWh
            </Text>
          </View>
        </View>
                <Text style={[styles.graphTitle, { color: textSecondary }]}>Consumo semanal</Text>
        <LineChart
          data={{
            labels: ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'],
            datasets: [
              {
                data: graficoSemanal,
                color: () => textPrimary,
                strokeWidth: 2,
              },
            ],
          }}
          width={screenWidth - 40}
          height={280}
          yAxisSuffix="kWh"
          bezier
          chartConfig={{
            backgroundGradientFrom: chartBackground,
            backgroundGradientTo: chartBackground,
            decimalPlaces: 1,
            color: (opacity = 1) => `rgba(198, 40, 40, ${opacity})`,
            labelColor: chartLabelColor,
            propsForDots: {
              r: '6',
              strokeWidth: '2',
              stroke: textPrimary,
            },
            style: {
              borderRadius: 16,
            },
          }}
          style={{
            marginVertical: 20,
            borderRadius: 16,
          }}
        />

        <Text style={[styles.graphTitle, { color: textSecondary }]}>Consumo mensal</Text>
        <LineChart
          data={{
            labels: [
              'Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun',
              'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez',
            ],
            datasets: [
              {
                data: graficoMensal,
                color: () => textPrimary,
                strokeWidth: 2,
              },
            ],
          }}
          width={screenWidth - 40}
          height={280}
          yAxisSuffix="kWh"
          chartConfig={{
            backgroundGradientFrom: chartBackground,
            backgroundGradientTo: chartBackground,
            decimalPlaces: 0,
            color: (opacity = 1) => `rgba(198, 40, 40, ${opacity})`,
            labelColor: chartLabelColor,
            propsForDots: {
              r: '5',
              strokeWidth: '2',
              stroke: textPrimary,
            },
            style: {
              borderRadius: 16,
            },
          }}
          style={{
            marginVertical: 20,
            borderRadius: 16,
          }}
        />

        <View style={{ height: 60 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: 20,
  },
  metricBox: {
    padding: 12,
    borderRadius: 10,
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 5,
  },
  metricLabel: {
    fontSize: 15,
  },
  metricValue: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  graphTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
    alignSelf: 'flex-start',
  },
});