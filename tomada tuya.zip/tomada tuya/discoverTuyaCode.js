import axios from "axios";
import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();

// ======== CONFIGURAÇÕES ========
const ACCESS_ID = process.env.TUYA_ACCESS_ID;
const ACCESS_SECRET = process.env.TUYA_ACCESS_SECRET;
const DEVICE_ID = process.env.TUYA_DEVICE_ID;
const TUYA_URL = process.env.TUYA_API_URL;

let TUYA_TOKEN = null;

// ======== FUNÇÃO DE ASSINATURA ========
function tuyaSignV2(path, method = "GET", body = "", accessToken = "") {
  const t = Date.now().toString();
  const bodyHash = crypto.createHash("sha256").update(body).digest("hex");
  const stringToSign = `${method}\n${bodyHash}\n\n${path}`;
  const signStr = ACCESS_ID + accessToken + t + stringToSign;
  const sign = crypto.createHmac("sha256", ACCESS_SECRET)
    .update(signStr, "utf8")
    .digest("hex")
    .toUpperCase();

  return { sign, t };
}

// ======== TOKEN ========
async function getTuyaToken() {
  const path = "/v1.0/token?grant_type=1";
  const { sign, t } = tuyaSignV2(path, "GET");
  const response = await axios.get(`${TUYA_URL}${path}`, {
    headers: {
      client_id: ACCESS_ID,
      sign,
      t,
      sign_method: "HMAC-SHA256",
    },
  });
  TUYA_TOKEN = response.data.result.access_token;
  console.log("✅ Token Tuya obtido com sucesso!");
}

// ======== DESCOBRIR CÓDIGOS ========
async function discoverDeviceCodes() {
  if (!TUYA_TOKEN) await getTuyaToken();

  const path = `/v1.0/devices/${DEVICE_ID}/status`;
  const { sign, t } = tuyaSignV2(path, "GET", "", TUYA_TOKEN);

  const response = await axios.get(`${TUYA_URL}${path}`, {
    headers: {
      client_id: ACCESS_ID,
      sign,
      t,
      sign_method: "HMAC-SHA256",
      access_token: TUYA_TOKEN,
    },
  });

  console.log("📡 Lista completa de datapoints do dispositivo:");
  console.table(response.data.result.map(r => ({
    code: r.code,
    value: r.value
  })));
}

await discoverDeviceCodes();