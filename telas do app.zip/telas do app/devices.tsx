import React, { useContext, useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from "react-native";
import { FontAwesome5 } from "@expo/vector-icons";
import { ThemeContext } from "../context/ThemeContext";
import { db } from "../config/firebaseConfig";
import { ref, onValue, set } from "firebase/database";
import * as Linking from "expo-linking";

export default function DevicesScreen() {
  const { darkMode } = useContext(ThemeContext);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [tuyaData, setTuyaData] = useState(null);
  const [goodweData, setGoodweData] = useState(null);

  const backgroundColor = darkMode ? "#0F0F0F" : "#FAFAFA";
  const textColor = darkMode ? "#FFFFFF" : "#212121";
  const cardColor = darkMode ? "#1E1E1E" : "#FFFFFF";

  // 🔄 Firebase Tuya e GoodWe
  useEffect(() => {
    const tuyaRef = ref(db, "dispositivos/tuya");
    const unsubTuya = onValue(tuyaRef, (snap) => {
      const data = snap.val();
      if (data) setTuyaData(data);
      setLoading(false);
      setRefreshing(false);
    });

    const goodweRef = ref(db, "dispositivos/goodwe");
    const unsubGoodwe = onValue(goodweRef, (snap) => {
      const data = snap.val();
      if (data) setGoodweData(data);
    });

    return () => {
      unsubTuya();
      unsubGoodwe();
    };
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  // 🔘 Ligar/desligar Tuya via Firebase
  const togglePlug = async () => {
    try {
      if (!tuyaData) return Alert.alert("Aviso", "Dispositivo não encontrado!");
      const newAction = tuyaData.online ? "off" : "on";
      await set(ref(db, "comandos/tuya"), { acao: newAction });
      Alert.alert(
        "Comando enviado",
        `Solicitado para ${newAction === "on" ? "ligar" : "desligar"} o dispositivo.`
      );
    } catch {
      Alert.alert("Erro", "Falha ao enviar comando para o Firebase.");
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={[styles.loadingContainer, { backgroundColor }]}>
        <ActivityIndicator size="large" color="#C62828" />
        <Text style={[styles.loadingText, { color: textColor }]}>
          Carregando dispositivos...
        </Text>
      </SafeAreaView>
    );
  }

  // 💡 Lista de dispositivos
  const devices = [
    {
      id: "1",
      icon: "plug",
      name: "Tomada Steck (Tuya)",
      status: tuyaData?.online ? "🟢 Ligado" : "🔴 Desligado",
      potencia: tuyaData?.power || 0,
      corrente: tuyaData?.current || 0,
      tensao: tuyaData?.voltage || 0,
      updatedAt: tuyaData?.updatedAt,
      type: "tuya",
    },
    {
      id: "2",
      icon: "solar-panel",
      name: "Inversor GoodWe",
      status: goodweData?.status || "Offline",
      potencia: goodweData?.power || 0,
      energiaHoje: goodweData?.todayEnergy || 0,
      total: goodweData?.totalEnergy || 0,
      temperatura: goodweData?.temperature || 0,
      updatedAt: goodweData?.updatedAt,
      type: "goodwe",
    },
    {
      id: "3",
      icon: "bolt",
      name: "Tomada Inteligente",
      status: "Online",
      potencia: 5,
      corrente: 1,
      tensao: 5,
      updatedAt: new Date().toISOString(),
      type: "simulada",
    },
  ];

  const renderDevice = ({ item }) => (
    <View style={[styles.card, { backgroundColor: cardColor }]}>
      <View style={styles.cardHeader}>
        <FontAwesome5 name={item.icon} size={26} color="#C62828" style={{ marginRight: 10 }} />
        <Text style={[styles.name, { color: textColor }]}>{item.name}</Text>
      </View>

      {item.type === "tuya" ? (
        <>
          <Text style={[styles.status, { color: textColor }]}>Status: {item.status}</Text>
          <Text style={[styles.status, { color: textColor }]}>Potência: {item.potencia} W</Text>
          <Text style={[styles.status, { color: textColor }]}>Corrente: {item.corrente} A</Text>
          <Text style={[styles.status, { color: textColor }]}>Tensão: {item.tensao} V</Text>
          <TouchableOpacity
            style={[styles.button, { backgroundColor: tuyaData?.online ? "#B71C1C" : "#2E7D32" }]}
            onPress={togglePlug}
          >
            <Text style={styles.buttonText}>
              {tuyaData?.online ? "Desligar dispositivo" : "Ligar dispositivo"}
            </Text>
          </TouchableOpacity>
        </>
      ) : item.type === "goodwe" ? (
        <>
          <Text style={[styles.status, { color: textColor }]}>Status: {item.status}</Text>
          <Text style={[styles.status, { color: textColor }]}>Potência atual: {item.potencia} W</Text>
          <Text style={[styles.status, { color: textColor }]}>Energia hoje: {item.energiaHoje} kWh</Text>
          <Text style={[styles.status, { color: textColor }]}>Total gerado: {item.total} kWh</Text>
          <Text style={[styles.status, { color: textColor }]}>Temperatura: {item.temperatura} °C</Text>
        </>
      ) : (
        <>
          <Text style={[styles.status, { color: textColor }]}>Status: {item.status}</Text>
          <Text style={[styles.status, { color: textColor }]}>Potência: {item.potencia} W</Text>
          <Text style={[styles.status, { color: textColor }]}>Corrente: {item.corrente} A</Text>
          <Text style={[styles.status, { color: textColor }]}>Tensão: {item.tensao} V</Text>
        </>
      )}

      {item.updatedAt && (
        <Text style={{ color: "#888", marginTop: 6, fontSize: 12, textAlign: "center" }}>
          Última atualização: {new Date(item.updatedAt).toLocaleTimeString()}
        </Text>
      )}
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor }]}>
      <Text style={[styles.title, { color: textColor }]}>Dispositivos Conectados</Text>

      <FlatList
        data={devices}
        renderItem={renderDevice}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ alignItems: "center", paddingBottom: 80 }}
        style={{ width: "100%" }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#C62828" />}
      />

      <View style={styles.footer}>
        <Text style={styles.alexaMessage}>Alexa está pronta para te ajudar com sua energia!</Text>
        <TouchableOpacity
          style={styles.alexaButton}
          onPress={() => Linking.openURL("alexa://devices")}
        >
          <FontAwesome5 name="amazon" size={22} color="#fff" style={{ marginRight: 8 }} />
          <Text style={styles.alexaText}>Conectar com Alexa</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", paddingTop: 30 },
  loadingContainer: { flex: 1, alignItems: "center", justifyContent: "center" },
  loadingText: { marginTop: 10, fontSize: 16 },
  title: { fontSize: 26, fontWeight: "700", marginBottom: 14 },
  name: { fontSize: 18, fontWeight: "bold" },
  status: { fontSize: 15, marginBottom: 3 },
  card: {
    width: "90%",
    borderRadius: 16,
    paddingVertical: 20,
    paddingHorizontal: 22,
    marginVertical: 10,
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 3,
  },
  cardHeader: { flexDirection: "row", alignItems: "center", marginBottom: 8 },
  button: {
    alignSelf: "center",
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 10,
  },
  buttonText: { color: "#fff", fontWeight: "bold", fontSize: 16 },
  footer: { position: "absolute", bottom: 30, alignItems: "center" },
  alexaMessage: { color: "#2E7D32", fontSize: 15, textAlign: "center", marginBottom: 10 },
  alexaButton: {
    flexDirection: "row",
    backgroundColor: "#232F3E",
    paddingVertical: 10,
    paddingHorizontal: 22,
    borderRadius: 10,
    alignItems: "center",
  },
  alexaText: { color: "#fff", fontSize: 17, fontWeight: "bold" },
});