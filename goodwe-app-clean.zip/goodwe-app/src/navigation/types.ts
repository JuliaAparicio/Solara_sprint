export type RootStackParamList = {
  Intro: undefined;
  Login: undefined;
  Register: undefined;
  MainTabs: undefined;
  FAQ: undefined;
  EditProfile: undefined;
};